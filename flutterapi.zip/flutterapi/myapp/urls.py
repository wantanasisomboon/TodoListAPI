from django.urls import path
from .views import *

urlpatterns = [
    path ('',Home),
    path('api/all-TodoList/',all_TodoList)
]