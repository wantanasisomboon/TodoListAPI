from django.contrib import admin
from myapp.models import TodoList

# Register your models here.
admin.site.register(TodoList)