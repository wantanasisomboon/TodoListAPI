from django.shortcuts import render
from django.http import JsonResponse

from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from .serializers import TodoListSerializer
from .models import TodoList

#GET Data
@api_view(['GET'])
def all_TodoList(request):
    allTodoList = TodoList.objects.all()
    serializer = TodoListSerializer(allTodoList,many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

# Create your views here.
data = {'message' : 'Hello'}

def Home(request):
    return JsonResponse(data=data, safe = False, json_dumps_params={'ensure_ascii' : False})