import 'dart:convert';
import 'dart:html';
import 'dart:js';

import 'package:flutter/material.dart';
import 'package:layout/pages/detail.dart';
import 'package:http/http.dart' as http;
import 'dart:async';

class HomePage extends StatefulWidget {
  //const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ความรู้เกี่ยวกับคอมพิวเตอร์"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child:   FutureBuilder(builder: (context, AsyncSnapshot snapshot) {
          //var data = json.decode(snapshot.data.toString());
          return ListView.builder(
            itemBuilder: (BuildContext context, int index) {
              return myBox(snapshot.data[index]['title'], snapshot.data[index]['sub_title'], snapshot.data[index]['image_url'], snapshot.data[index]['detail'], context);
            },
            itemCount: snapshot.data.length, );

        },
        future: getData(),
        //future: DefaultAssetBundle.of(context).loadString('assets/data.json'),
       
        )

      ),
    );
  }

//สร้าง Widget ชื่อ MyBox
  Widget myBox(String title, String subtitle, String image_url, String detail, context) {
    return Container(
      padding: EdgeInsets.all(20),
      //color: Colors.green[100],
      height: 180,
      //add รูป
      decoration: BoxDecoration(
        color: Colors.green[100],
        borderRadius: BorderRadius.circular(20),
        image: DecorationImage(
          image: NetworkImage(
            image_url),
          fit:BoxFit.cover,
          colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.25), BlendMode.darken)
      ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 25, color: Colors.green[100],fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          Text(
            subtitle,
            style: TextStyle(fontSize: 15, color: Colors.green[100]),
          ),
          SizedBox(height: 10),
          TextButton(onPressed: (){
              print("Next Page >>>");
             // Navigator.push(context, MaterialPageRoute(builder: (context)=> DetailPage()));
              }, child: Text("Next Page >>>"))
        ],
      ),
    );
  }
}

//สร้าง futurefunction
Future getData () async {
    var url =Uri.https('raw.githubusercontent.com', '/wantanasisomboon/BasicAPI/main/data2.json');
    //var url =Uri.http('69bc-202-28-78-133.ngrok.io', '/');
    var response = await http.get(url);
    var result = json.decode(response.body);
    return result;


}
